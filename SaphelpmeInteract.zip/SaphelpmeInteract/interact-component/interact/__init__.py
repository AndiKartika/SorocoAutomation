"""Imports base classes so they are accessible from the package itself."""

from .interact_htmlapplication import InteractHtmlApplication

__all__ = ["InteractHtmlApplication"]