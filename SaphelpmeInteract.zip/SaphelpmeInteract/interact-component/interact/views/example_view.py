"""This module contains ExampleView class."""

from soroco.htmlcomponent import HtmlApplication
from soroco.htmlcomponent.primitives import Button
from soroco.htmlengine import HtmlPointer
from soroco.uicomponent.view import View


class ExampleView(View):
    """
    View class for Example view.

    Args:
        application (HtmlApplication): Main html application object.
    """

    class Selectors:
        """Selector class for ExampleView."""

        example = ""  # TODO: Add proper selector string here

    def __init__(self, application: HtmlApplication) -> None:
        self.parent_pointer = application.html
        self.example = Button(
            parent_pointer=self.parent_pointer,
            selector_string=self.Selectors.example,
            timeout=5,
        )

    @staticmethod
    def validate(parent_pointer: HtmlPointer, timeout: int = 3) -> bool:
        """
        Validate whether the view is currently visible or not.

        Args:
            parent_pointer (HtmlPointer): Pointer to the view window element.
            timeout (int): The maximum time to spend waiting for the identifier
                element to be selected.

        Returns:
            bool: True if validation is successful else False.
        """
        return (
            parent_pointer.select(
                selector=ExampleView.Selectors.example, timeout=timeout
            )
            is not None
        )
