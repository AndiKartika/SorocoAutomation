"""Imports view classes so they are accessible from the package itself."""
from .example_view import ExampleView

__all__ = ["ExampleView"]
