import logging

from soroco.htmlcomponent import HtmlApplication

log = logging.getLogger(__name__)


class InteractHtmlApplication(HtmlApplication):
    """Application class for Financial Pro."""

    def close(self) -> None:
        """
        Close the application gracefully by clicking on close button in titlebar.

        Returns:
             None
        """
        self.webdriver.execute('quit')
