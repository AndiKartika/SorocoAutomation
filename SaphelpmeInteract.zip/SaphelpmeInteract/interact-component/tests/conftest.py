"""Contains fixtures used by test code."""

import platform
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any, Generator

import pytest
import tests.constants as constants
from soroco.logger import Logger


@pytest.fixture
def temp_dir() -> Generator[Path, None, None]:
    """
    Get temporary directory as a fixture.

    The temporary directory gets deleted after its use in test case.

    Returns:
        Generator[Path, None, None]
    """
    with TemporaryDirectory() as temp_dir_:
        yield Path(temp_dir_)
    return


@pytest.fixture
def setup_logger(temp_dir: Path) -> Generator[None, None, None]:
    """
    Set up Logger to put logs in a temporary directory.

    Returns:
        Generator[None, None, None]
    """
    Logger.setup(
        temp_dir / constants.LOG_DIR,
        filename=constants.LOG_FILE_NAME,
        config_dict={
            "from_console": True,
            "to_console": True,
            "log_levels": {"root": "INFO"},
        },
    )
    yield
    Logger.teardown()
    return


@pytest.fixture
def setup_screenshot(temp_dir: Path) -> Generator[None, None, None]:
    """
    Set up screenshot for screenshot capture.

    Puts captured screenshots in temporary directory.

    Returns:
        Generator[None, None, None]
    """
    if platform.system() == "Windows":
        from soroco.screenshot import Screenshot

        Screenshot.setup(temp_dir / constants.SCREENSHOT_DIR)
        yield
        Screenshot.teardown()
    else:
        yield
    return
