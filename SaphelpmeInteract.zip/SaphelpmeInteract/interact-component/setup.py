"""Setup script for interact-component."""
from typing import List

from setuptools import find_packages, setup

# Package meta-data.
NAME = "interact-component"
VERSION = "1.0.0"
DESCRIPTION = "An application component"
LONG_DESCRIPTION = "Add long description here"
AUTHOR = "Andi Kartika"
EMAIL = "<author-email>"
URL = "<source-control-url>"
REQUIRES_PYTHON = ">=3.6.0"
CLASSIFIERS = ["Programming Language :: Python :: 3.6", "application-type :: html"]


# #########################################################################
# ADD ADDITIONAL REQUIREMENTS OF THE PACKAGE
# #########################################################################

# Platform independent requirements
REQUIREMENTS: List[str] = [
    "soroco.automation-libs==2.5.3",
]

# Windows specific requirements
WINDOWS_REQUIREMENTS: List[str] = []

# Linux specific requirements
LINUX_REQUIREMENTS: List[str] = []

# #########################################################################

# We need to append the following identifier to specify platform dependency
# https://setuptools.readthedocs.io/en/latest/setuptools.html#declaring-platform-specific-dependencies
win_requirements_identifier = '; platform_system == "Windows"'
linux_requirements_identifier = '; platform_system == "Linux"'

REQUIREMENTS.extend([req + win_requirements_identifier for req in WINDOWS_REQUIREMENTS])
REQUIREMENTS.extend([req + linux_requirements_identifier for req in LINUX_REQUIREMENTS])

# Main setup entry script
# Read more about the setup meta-data on the link below :
# https://docs.python.org/3.6/distutils/setupscript.html#meta-data
if __name__ == "__main__":
    setup(
        name=NAME,
        version=VERSION,
        description=DESCRIPTION,
        long_description=LONG_DESCRIPTION,
        long_description_content_type="text/markdown",
        author=AUTHOR,
        author_email=EMAIL,
        python_requires=REQUIRES_PYTHON,
        url=URL,
        packages=find_packages(include="interact/*"),
        # If your package is a single module, use py_modules instead of 'packages':
        # py_modules=['mypackage'],
        install_requires=REQUIREMENTS,
        include_package_data=True,
        license='Copyright (c) 2019 Soroco Private Limited ("Soroco")',
        classifiers=CLASSIFIERS,
    )
