"""Setup script for saphelpme-interact."""
from typing import List

from setuptools import find_packages, setup

# Package meta-data.
NAME = "saphelpme-interact"
VERSION = "1.0.0"
DESCRIPTION = "An automation system to automate SRQ creation via SNOW Interact Portal"
LONG_DESCRIPTION = "An automation system to automate SRQ creation via SNOW Interact Portal"
AUTHOR = "Andi Kartika"
EMAIL = "andi.kartika@sampoerna.com"
URL = "https://source.app.pconnect.biz/scm/oas/soroco-saphelpme-interact.git"
REQUIRES_PYTHON = ">=3.6.0"
CLASSIFIERS = ['Programming Language :: Python :: 3.6']


# #########################################################################
# ADD ADDITIONAL REQUIREMENTS OF THE PACKAGE
# #########################################################################

# Platform independent requirements
REQUIREMENTS: List[str] = ["soroco.automation-libs==2.5.3", ]

# Windows specific requirements
WINDOWS_REQUIREMENTS: List[str] = []

# Linux specific requirements
LINUX_REQUIREMENTS: List[str] = []

# #########################################################################

# We need to append the following identifier to specify platform dependency
# https://setuptools.readthedocs.io/en/latest/setuptools.html#declaring-platform-specific-dependencies
win_requirements_identifier = '; platform_system == "Windows"'
linux_requirements_identifier = '; platform_system == "Linux"'

REQUIREMENTS.extend([req + win_requirements_identifier for req in WINDOWS_REQUIREMENTS])
REQUIREMENTS.extend([req + linux_requirements_identifier for req in LINUX_REQUIREMENTS])

# Main setup entry script
# Read more about the setup meta-data on the link below :
# https://docs.python.org/3.6/distutils/setupscript.html#meta-data
if __name__ == "__main__":
    setup(
        name=NAME,
        version=VERSION,
        description=DESCRIPTION,
        long_description=LONG_DESCRIPTION,
        long_description_content_type="text/markdown",
        author=AUTHOR,
        author_email=EMAIL,
        python_requires=REQUIRES_PYTHON,
        url=URL,
        packages=find_packages(include="saphelpme_interact_automation/*"),
        # If your package is a single module, use py_modules instead of 'packages':
        # py_modules=['mypackage'],
        entry_points={'console_scripts': ['run_automation_system=saphelpme_interact_automation: run']},
        
        install_requires=REQUIREMENTS,
        include_package_data=True,
        license='Copyright (c) 2019 Soroco Private Limited ("Soroco")',
        classifiers=CLASSIFIERS,
    )