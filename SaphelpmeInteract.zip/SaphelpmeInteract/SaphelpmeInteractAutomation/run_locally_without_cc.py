#  ------------------------------- START OF LICENSE NOTICE -----------------------------
#  Copyright (c) 2020 Soroco Private Limited. All rights reserved.
#
#  NO WARRANTY. THE PRODUCT IS PROVIDED BY SOROCO "AS IS" AND ANY EXPRESS OR IMPLIED
#  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
#  AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL SOROCO BE
#  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
#  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
#  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
#  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE PRODUCT, EVEN IF
#  ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#  -------------------------------- END OF LICENSE NOTICE ------------------------------
"""
This module runs automation process locally.



Note:
    This module runs automation process locally without any CC. If your automation
    process requires services like Confidential, Minio etc. from CC, then you
    must mock their usages in this file.
"""
from saphelpme_interact_automation.entry import setup_automations

def main() -> None:
    """Run automation process locally."""
    automation = setup_automation()

    queued_work_list = automation.run_process_locally(
        automation_process_name="InteractFormProcessor"
        ,data_dir=".data-dir"#,
        # database_url="sqlite:///test.db",
    )

    while queued_work_list:
        work = queued_work_list[0]
        queued_work_list.remove(work)
        works = automation.run_process_locally(
            work.automation_process_name, ".data-dir", work.workunit
        )
        queued_work_list.extend(works)


if __name__ == "__main__":
    main()
