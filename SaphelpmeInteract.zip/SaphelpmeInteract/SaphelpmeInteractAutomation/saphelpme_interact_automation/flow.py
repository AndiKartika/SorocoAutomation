#  ------------------------------- START OF LICENSE NOTICE -----------------------------
#  Copyright (c) 2020 Soroco Private Limited. All rights reserved.
#
#  NO WARRANTY. THE PRODUCT IS PROVIDED BY SOROCO "AS IS" AND ANY EXPRESS OR IMPLIED
#  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
#  AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL SOROCO BE
#  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
#  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
#  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
#  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE PRODUCT, EVEN IF
#  ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#  -------------------------------- END OF LICENSE NOTICE ------------------------------
"""
Define flow of business logic in the form of `AutomationProcess`s.

An `Automation process` is a collection of business process step.

An automation process should ideally operate on a unit of workunits. A unit of
workunits can be thought of as the fundamental piece of information for an
AutomationProcess to process, run automation on and modify.

AutomationProcess objects are defined here along with its specifications:
  - Input/output processes
  - Definition of workunits (WorkUnit)

Work are defined within `tutorial/account.py`

During its execution an AutomationProcess may queue workunits for other processes. A
process may pass along the same workunit object, or create a new workunit object to be
processed by any other AutomationProcess.
"""
import platform

AUTOMATION_PROCESSES = []
if platform.system() == "Windows":

    # ###########################################################
    # Add process modules which should be able to run on windows
    # ###########################################################

    from saphelpme_interact_automation.processes.interact_form_processor import (
        InteractFormProcessor,
    )
    from saphelpme_interact_automation.workunits import srq_details

    AUTOMATION_PROCESSES.append(
        InteractFormProcessor(takes_input=False, workunit_class=srq_details,),
    )

elif platform.system() == "Linux":

    # ###########################################################
    # Add process modules which should be able to run on Linux
    # ###########################################################

    AUTOMATION_PROCESSES = []
else:
    raise OSError("Unsupported platform, only windows and linux supported")
