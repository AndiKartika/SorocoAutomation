#  ------------------------------- START OF LICENSE NOTICE -----------------------------
#  Copyright (c) 2020 Soroco Private Limited. All rights reserved.
#
#  NO WARRANTY. THE PRODUCT IS PROVIDED BY SOROCO "AS IS" AND ANY EXPRESS OR IMPLIED
#  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
#  AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL SOROCO BE
#  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
#  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
#  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
#  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE PRODUCT, EVEN IF
#  ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#  -------------------------------- END OF LICENSE NOTICE ------------------------------
"""
Automation system entry point.

DO NOT MODIFY THIS FILE UNLESS YOU KNOW WHAT YOU ARE DOING.
"""
import argparse
import logging

from saphelpme_interact_automation.flow import AUTOMATION_PROCESSES

from soroco.automation_framework import Automation

logger = logging.getLogger(__name__)


def register_processes(automation: Automation,) -> None:
    """
    Register all the process objects with the AutomationSystem object.

    Registering is where the AutomationSystem object learns about the existence of the
    processes that constitute it. Registering is also where a process gets
    certain class attributes initialized

    Args:
        automation: AutomationSystem object with which to register the processes
    """
    for automation_process in AUTOMATION_PROCESSES:
        automation.register_process(automation_process)


def setup_automation() -> Automation:
    """
    Set up the automation.

    Returns:
        Initialized Automation object.
    """
    # You can edit the arguments passed to Automation()
    automation = Automation(
        logger_config={
            "from_console": True,
            "to_console": True,
            "log_levels": {"root": "INFO"},
        },
    )
    register_processes(automation)
    return automation


def parse_args() -> argparse.Namespace:
    """
    Parse arguments from command line.

    Returns:
        The parsed arguments.
    """
    parser = argparse.ArgumentParser()

    parser.add_argument("--spawn-id", type=str, required=True)
    parser.add_argument(
        "--automation-process-name", type=str, required=True,
    )
    parser.add_argument("--data-dir", type=str, required=True)
    parser.add_argument(
        "--deployment-namespace", type=str, required=True,
    )
    parser.add_argument(
        "--services-config", type=str, required=True,
    )

    args, _ = parser.parse_known_args()

    return args


def run() -> None:
    """
    Run the automation with arguments from commandline.

    Returns:
        None
    """
    args = parse_args()

    automation = setup_automation()
    automation.run(
        spawn_id=args.spawn_id,
        deployment_namespace=args.deployment_namespace,
        automation_process_name=args.automation_process_name,
        data_dir=args.data_dir,
        services_config_path=args.services_config,
    )
