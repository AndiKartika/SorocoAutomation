#  ------------------------------- START OF LICENSE NOTICE -----------------------------
#  Copyright (c) 2020 Soroco Private Limited. All rights reserved.
#
#  NO WARRANTY. THE PRODUCT IS PROVIDED BY SOROCO "AS IS" AND ANY EXPRESS OR IMPLIED
#  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
#  AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL SOROCO BE
#  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
#  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
#  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
#  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THE PRODUCT, EVEN IF
#  ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#  -------------------------------- END OF LICENSE NOTICE ------------------------------
"""Interact Form Processor Automation Process."""
import logging
from typing import Type
from soroco.htmlengine import BrowserType

from interactform import InteractFormHtmlApplication
from saphelpme_interact_automation.utilities import Constants
from saphelpme_interact_automation.workunits import srq_details


from soroco.automation_framework import AutomationProcess
from soroco.workunit import BusinessError, WorkUnit

log = logging.getLogger(__name__)

class InteractFormProcessor(AutomationProcess):
    """
    Class defining AccountProcessor.

    In AccountProcessor process, below steps are performed:
        1. Read data from PDF.
        2. Add data in FinancialPro application.
        3. Create account in AccountPro application.
    """

    def __init__(self, takes_input: bool, workunit_class: Type[WorkUnit],) -> None:
        super().__init__(takes_input, workunit_class)
        self.workunit: srq_details = None
        self.interactform: InteractFormHtmlApplication = None
        # self.finance_pro: FinancialProApplication = None

    def run(self) -> None:
        """
        Run process AccountProcessor.

        Returns:
            None
        """
        # Read email via IMAP and collect input

        # Open Web Application and fill form
        self.interactform = InteractFormHtmlApplication(url="https://www.google.com", browser_type=BrowserType.Chrome)

    def handle_exception(self, exception: Exception) -> None:
        """
        Handle exceptions which are not for process failure.

        Args:
            exception (Exception): Exception raised by run method.

        Returns:
            None
        """
        if (
            isinstance(exception, BusinessError)
            # and AccountErrorCode.Risky 
            in exception.error_codes
        ):
            log.info("Business error ...")
        else:
            # If there is any other exception we re-raise it to mark spawn as failure
            raise exception

    def end(self) -> None:
        """
        End the automation process run.

        This method gets called after run method and even if there is an
        exception raised by run, it will still be called.

        Closes the components if they are open.

        Returns:
            None
        """
        if self.interactform:
            self.interactform.close()
            log.info("Successfully closed Interact Form application")

        # if self.finance_pro:
        #     self.finance_pro.close()
        #     log.info("Successfully closed FinancialPro application")