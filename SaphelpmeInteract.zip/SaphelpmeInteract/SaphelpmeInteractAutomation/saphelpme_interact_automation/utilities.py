class Constants:
    """This class contains all the file paths."""

    interact_form_url = ""
