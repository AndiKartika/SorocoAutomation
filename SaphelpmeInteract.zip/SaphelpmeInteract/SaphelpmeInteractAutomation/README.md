# saphelpme_interact
An automation system to automate SRQ creation via SNOW Interact Portal