from soroco.htmlengine import HtmlPointer

from soroco.htmlcomponent.primitives import TextBox, Button
from soroco.htmlcomponent.views import BrowserWindowView
from soroco.htmlcomponent import HtmlApplication

class FormView(BrowserWindowView):

    class Selectors:
        short_desc = "@textarea#sp_formfield_short_description"
        description = "@textarea#sp_formfield_description"

    def __init__(self, htmlapplication: HtmlApplication) -> None:
        """
        Initialize the UI elements as attributes.

        Args:
            htmlapplication (HtmlApplication): html application.

        Returns:
            None
        """
        super().__init__(htmlapplication)
        self.parent_pointer = htmlapplication.html.select()
        self.short_desc = TextBox(self.parent_pointer, FormView.Selectors.short_desc)
        self.description = TextBox(self.parent_pointer, FormView.Selectors.description)


    @staticmethod
    def validate(parent_pointer: HtmlPointer, timeout: int = 15000) -> bool:
        """
        Validate whether the View is currently visible or not.

        Args:
            parent_pointer (HtmlPointer): Pointer to the parent element.
            timeout (int): The maximum time to spend waiting for the
                identifier element to be selected.

        Returns:
            bool: True if the validation is successful otherwise False
        """
        textarea_pointer = parent_pointer.select(
                FormView.Selectors.short_desc, timeout)
        return textarea_pointer is not None
