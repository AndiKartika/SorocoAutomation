from views.form_view import FormView
from soroco.htmlengine import BrowserType
from soroco.htmlcomponent import HtmlApplication
from interact_form_htmlapplication import InteractFormHtmlApplication
import time

def main() -> None:
    html_application = InteractFormHtmlApplication(url="https://pmiv.service-now.com/interact?id=sc_cat_item&sys_id=999cc8dbdb5160141d11b9836b9619ef", browser_type=BrowserType.InternetExplorer)

    time.sleep(15)
    form_view: FormView = \
        html_application.validate_and_get_view(FormView)
    form_view.short_desc.set_value("Test Short Desc")
    form_view.description.set_value("Test Long Desc")
    # html_application.close()


if __name__ == '__main__':
    main()