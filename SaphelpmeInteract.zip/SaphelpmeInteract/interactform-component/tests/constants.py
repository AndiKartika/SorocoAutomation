"""Contains constants used in tests."""

LOG_DIR = "logs"
LOG_FILE_NAME = "test.log"
SCREENSHOT_DIR = "screenshot"